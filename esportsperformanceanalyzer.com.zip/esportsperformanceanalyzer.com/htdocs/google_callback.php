<?php
session_start();
include "db.php";

$client_id = "1031095676164-2eo37u5ns7e254n275ocjiqng2cm8dt6.apps.googleusercontent.com";
$client_secret = "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";
$redirect_uri = "https://esportsperformanceanalyzer.com/google_callback.php";

if (!isset($_GET['code'])) {
    die("Google login failed.");
}

$code = $_GET['code'];

$data = [
    "code" => $code,
    "client_id" => $client_id,
    "client_secret" => $client_secret,
    "redirect_uri" => $redirect_uri,
    "grant_type" => "authorization_code"
];

$options = [
    "http" => [
        "header" => "Content-Type: application/x-www-form-urlencoded\r\n",
        "method" => "POST",
        "content" => http_build_query($data)
    ]
];

$response = file_get_contents("https://oauth2.googleapis.com/token", false, stream_context_create($options));

if ($response === false) {
    die("Token request failed.");
}

$token = json_decode($response, true);

if (!isset($token['access_token'])) {
    die("Token error: " . htmlspecialchars($response));
}

$user_info = file_get_contents("https://www.googleapis.com/oauth2/v2/userinfo?access_token=" . $token['access_token']);

if ($user_info === false) {
    die("Failed to fetch user info.");
}

$user = json_decode($user_info, true);

$email = $user['email'];
$name = $user['name'];

$check = $conn->query("SELECT * FROM users WHERE email='$email'");

if ($check->num_rows == 0) {
    $password = password_hash("google_login", PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (email, password, riot_id) VALUES ('$email', '$password', '')");
}

$_SESSION['user'] = $email;
$_SESSION['name'] = $name;

header("Location: /dashboard.php");
exit();
?>