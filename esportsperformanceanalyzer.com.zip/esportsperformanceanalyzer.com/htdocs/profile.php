<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['user'];
$name = $_SESSION['name'] ?? "User";
$riotId = "";

/* Save / Update Riot ID */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["riot_id"])) {
    $newRiotId = trim($_POST["riot_id"]);

    $stmt = $conn->prepare("UPDATE users SET riot_id = ? WHERE email = ?");
    $stmt->bind_param("ss", $newRiotId, $email);
    $stmt->execute();

    header("Location: profile.php");
    exit();
}

/* Remove Riot ID */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["remove_riot_id"])) {
    $stmt = $conn->prepare("UPDATE users SET riot_id = NULL WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    header("Location: profile.php");
    exit();
}

/* Fetch Riot ID */
$stmt = $conn->prepare("SELECT riot_id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $riotId = $row["riot_id"] ?? "";
}

$trackerUrl = "";
if (!empty($riotId) && strpos($riotId, "#") !== false) {
    [$gameName, $tagLine] = explode("#", $riotId, 2);
    $trackerUrl = "https://tracker.gg/valorant/profile/riot/" . urlencode($gameName) . "%23" . urlencode($tagLine) . "/overview";
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>My Profile | Esports Performance Analyzer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="icon" type="image/png" href="./dist/assets/img/Logo.png">
  <link rel="stylesheet" href="./dist/css/adminlte.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

  <style>
    body.dark-mode {
      background-color: #121212;
      color: #ffffff;
    }

    body.dark-mode .card,
    body.dark-mode .app-main,
    body.dark-mode .content-wrapper {
      background-color: #1e1e1e;
      color: #ffffff;
    }

    body.dark-mode .card-header {
      background-color: #252525;
      color: #ffffff;
    }

    body.dark-mode .form-control {
      background-color: #2b2b2b;
      color: #ffffff;
      border-color: #444;
    }

    body.dark-mode .text-muted {
      color: #bbbbbb !important;
    }
  </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">

  <!-- Navbar -->
  <nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
            <i class="bi bi-list"></i>
          </a>
        </li>
        <li class="nav-item d-none d-md-block">
          <a href="/" class="nav-link">Dashboard</a>
        </li>
      </ul>

      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <span class="nav-link">
            <i class="bi bi-person-circle"></i>
            <?php echo htmlspecialchars($name); ?>
          </span>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Sidebar -->
  <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
      <a href="/" class="brand-link">
        <img src="./dist/assets/img/Logo.png" alt="Logo" class="brand-image opacity-75 shadow">
        <span class="brand-text fw-light">Esports Analyzer</span>
      </a>
    </div>

    <div class="sidebar-wrapper">
      <nav class="mt-2">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu">

          <li class="nav-item">
            <a href="/" class="nav-link">
              <i class="nav-icon bi bi-speedometer"></i>
              <p>Dashboard</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="./profile.php" class="nav-link active">
              <i class="nav-icon bi bi-person-circle"></i>
              <p>My Profile</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="./matches.php" class="nav-link">
              <i class="nav-icon bi bi-controller"></i>
              <p>Matches</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="./player-stats.php" class="nav-link">
              <i class="nav-icon bi bi-bar-chart"></i>
              <p>Player Stats</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="./analytics.php" class="nav-link">
              <i class="nav-icon bi bi-graph-up"></i>
              <p>Analytics</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="./settings.php" class="nav-link">
              <i class="nav-icon bi bi-gear"></i>
              <p>Settings</p>
            </a>
          </li>

        </ul>
      </nav>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="app-main">
    <div class="app-content-header">
      <div class="container-fluid">
        <h3 class="mb-0">My Profile</h3>
      </div>
    </div>

    <div class="app-content">
      <div class="container-fluid">

        <div class="row">
          <div class="col-md-4">
            <div class="card card-primary card-outline">
              <div class="card-body box-profile text-center">
                <i class="bi bi-person-circle display-1"></i>

                <h3 class="profile-username mt-3">
                  <?php echo htmlspecialchars($name); ?>
                </h3>

                <p class="text-muted">
                  <?php echo htmlspecialchars($email); ?>
                </p>

                <hr>

                <strong><i class="bi bi-controller me-1"></i> Linked Riot ID</strong>

                <p class="text-muted mt-2">
                  <?php echo !empty($riotId) ? htmlspecialchars($riotId) : "No Riot ID linked yet"; ?>
                </p>

                <?php if (!empty($trackerUrl)): ?>
                  <a href="<?php echo htmlspecialchars($trackerUrl); ?>" target="_blank" class="btn btn-primary btn-sm">
                    View on Tracker Network
                  </a>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Manage Riot Account</h3>
              </div>

              <div class="card-body">
                <form method="POST" action="profile.php">
                  <div class="mb-3">
                    <label class="form-label">Riot ID</label>
                    <input 
                      type="text" 
                      name="riot_id" 
                      class="form-control" 
                      placeholder="Example: PlayerName#1234"
                      value="<?php echo htmlspecialchars($riotId); ?>"
                      required
                    >
                  </div>

                  <button type="submit" class="btn btn-success">
                    <i class="bi bi-check-circle"></i>
                    Save Riot ID
                  </button>
                </form>

                <?php if (!empty($riotId)): ?>
                  <form method="POST" action="profile.php" class="mt-3">
                    <input type="hidden" name="remove_riot_id" value="1">
                    <button type="submit" class="btn btn-danger">
                      <i class="bi bi-trash"></i>
                      Remove Riot ID
                    </button>
                  </form>
                <?php endif; ?>
              </div>
            </div>

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Profile Overview</h3>
              </div>

              <div class="card-body">
                <p><strong>Account Status:</strong> Active</p>
                <p><strong>Connected Game:</strong> Valorant</p>
                <p><strong>Data Source:</strong> Tracker Network</p>
                <p class="text-muted mb-0">
                  Your profile connects your website account with your Riot ID. Match history, stats, and analytics will use this linked Riot account.
                </p>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  </main>

  <footer class="app-footer">
    <strong>© 2026 Esports Performance Analyzer</strong>
  </footer>

</div>

<script src="./dist/js/adminlte.js"></script>

<script>
  if (localStorage.getItem("darkMode") === "enabled") {
    document.body.classList.add("dark-mode");
  }
</script>

</body>
</html>