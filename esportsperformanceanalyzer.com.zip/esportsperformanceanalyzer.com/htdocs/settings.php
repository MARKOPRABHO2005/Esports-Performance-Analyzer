<?php
session_start();

$name = $_SESSION['name'] ?? "Account";
$email = $_SESSION['user'] ?? "";
$isLoggedIn = isset($_SESSION['user']);

$page = file_get_contents("dist/index.html");

/* Fix paths */
$page = str_replace('href="./', 'href="dist/', $page);
$page = str_replace('src="./', 'src="dist/', $page);

/* Fix favicon */
$page = str_replace(
    'href="dist/assets/img/Logo.png"',
    'href="/dist/assets/img/Logo.png"',
    $page
);

/* Navigation */
$page = str_replace('href="./index.html"', 'href="/"', $page);
$page = str_replace('href="dist/index.html"', 'href="/"', $page);
$page = str_replace('href="./settings.html"', 'href="/settings.php"', $page);

/* Account name */
$page = str_replace(
    '<i class="bi bi-person-circle"></i> Account',
    '<i class="bi bi-person-circle"></i> ' . htmlspecialchars($name),
    $page
);

/* Login/Register/Logout */
if ($isLoggedIn) {

    /* Top dropdown */
    $page = str_replace(
        'Register / Sign Up',
        'Logged in as:<br><b>' . htmlspecialchars($email) . '</b>',
        $page
    );

    $page = str_replace(
        'Already a user? Login',
        'Logout',
        $page
    );

    $page = str_replace('../register.php', '/logout.php', $page);
    $page = str_replace('../login.php', '/logout.php', $page);

    /* Sidebar */
    $page = str_replace('<p>Register</p>', '<p>Logout</p>', $page);
    $page = str_replace('<p>Login</p>', '<p>Logout</p>', $page);

    $page = str_replace('bi bi-person-plus', 'bi bi-box-arrow-right', $page);
    $page = str_replace('bi bi-box-arrow-in-right', 'bi bi-box-arrow-right', $page);

} else {

    $page = str_replace('../register.php', '/register.php', $page);
    $page = str_replace('../login.php', '/login.php', $page);
}

$page = str_replace(
    'Home / Settings',
    'Home / Esports Dashboard',
    $page
);

$page = str_replace(
    '<a href="/" class="text-decoration-none">Home</a> / <span>Settings</span>',
    '<a href="/" class="text-decoration-none">Home / Esports Dashboard</a>',
    $page
);

/* SETTINGS CONTENT */
$settingsContent = '
<div class="app-content">
  <div class="container-fluid">

    <h3 class="mb-4">Settings</h3>

    <p class="fs-5 mb-4">
      Manage FAQs, Chatbot Support, System Theme,
      Notifications, and Account Security.
    </p>

    <div class="row">

      <!-- LEFT COLUMN -->
      <div class="col-md-6 d-flex flex-column">

        <!-- FAQ -->
        <div class="card mb-4">
          <div class="card-body">

            <h5><i class="bi bi-question-circle"></i> FAQs</h5>

            <p>Common questions about Esports Performance Analyzer.</p>

            <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#faqBox">
              Open FAQs
            </button>

            <div class="collapse mt-3" id="faqBox">

              <p><b>Q1:</b> How do I link my Riot ID?<br>
              <b>A:</b> Login and enter your Riot ID on the dashboard.</p>

              <p><b>Q2:</b> Can I remove Riot ID?<br>
              <b>A:</b> Yes, from the dashboard.</p>

              <p><b>Q3:</b> Why are stats not showing?<br>
              <b>A:</b> Check Riot ID spelling and tag.</p>

              <p><b>Q4:</b> What does Analytics show?<br>
              <b>A:</b> Match and player performance data.</p>

              <p><b>Q5:</b> How do I logout?<br>
              <b>A:</b> Use Logout from sidebar/account menu.</p>

            </div>

          </div>
        </div>

        <!-- THEME -->
        <div class="card mb-4">
          <div class="card-body">

            <h5><i class="bi bi-moon-stars"></i> System Theme</h5>

            <p>Switch between light mode and dark mode.</p>

            <div class="form-check form-switch">

              <input
                class="form-check-input"
                type="checkbox"
                id="darkModeSwitch"
              >

              <label
                class="form-check-label"
                for="darkModeSwitch"
              >
                Enable Dark Theme
              </label>

            </div>

          </div>
        </div>

        <!-- NOTIFICATIONS -->
        <div class="card mb-4">
          <div class="card-body">

            <h5><i class="bi bi-bell"></i> Notifications</h5>

            <p>Choose which alerts you want to receive.</p>

            <div class="form-check">
              <input class="form-check-input" type="checkbox" checked>
              <label class="form-check-label">
                Email Notifications
              </label>
            </div>

            <div class="form-check">
              <input class="form-check-input" type="checkbox">
              <label class="form-check-label">
                Match Alerts
              </label>
            </div>

            <div class="form-check">
              <input class="form-check-input" type="checkbox">
              <label class="form-check-label">
                Weekly Reports
              </label>
            </div>

          </div>
        </div>

      </div>

      <!-- RIGHT COLUMN -->
      <div class="col-md-6 d-flex flex-column">

        <!-- CHATBOT -->
        <div class="card mb-4">
          <div class="card-body">

            <h5><i class="bi bi-robot"></i> Chatbot</h5>

            <p>
              Ask questions about Riot ID, analytics, matches,
              teams, reports, login, and settings.
            </p>

            <div
              id="chatBox"
              class="border rounded p-3 mb-3"
              style="
                height:220px;
                overflow-y:auto;
                background:#f8f9fa;
              "
            >

              <div>
                <b>Bot:</b>
                Hi! Ask me anything about Esports Performance Analyzer.
              </div>

            </div>

            <div class="input-group">

              <input
                type="text"
                class="form-control"
                id="chatInput"
                placeholder="Type your question..."
              >

              <button
                class="btn btn-success"
                type="button"
                onclick="chatReply()"
              >
                Send
              </button>

            </div>

          </div>
        </div>

        <!-- PRIVACY -->
        <div class="card mb-4">
          <div class="card-body">

            <h5><i class="bi bi-shield-lock"></i> Privacy & Security</h5>

            <p>
              Manage login sessions, Riot ID privacy,
              and account security.
            </p>

            <a
              href="/security.php"
              class="btn btn-danger"
            >
              Security Settings
            </a>

          </div>
        </div>

      </div>

    </div>
  </div>
</div>
';

/* Replace dashboard content */
$page = preg_replace(
    '/<div class="app-content">.*?<!--end::App Content-->/s',
    $settingsContent . "\n<!--end::App Content-->",
    $page,
    1
);

/* DARK MODE CSS */
$page = str_replace(
    '</style>',
    '

    .dark-mode {
      background-color: #121212 !important;
      color: #ffffff !important;
    }

    .dark-mode .app-main,
    .dark-mode .app-content,
    .dark-mode .container-fluid,
    .dark-mode .app-content-header {
      background-color: #121212 !important;
      color: #ffffff !important;
    }

    .dark-mode .card,
    .dark-mode .navbar,
    .dark-mode .app-header,
    .dark-mode .small-box {
      background-color: #1f1f1f !important;
      color: #ffffff !important;
    }

    .dark-mode .form-control {
      background-color: #2a2a2a !important;
      color: #ffffff !important;
      border-color: #555 !important;
    }

    .dark-mode #chatBox {
      background-color: #2a2a2a !important;
      color: #ffffff !important;
      border-color: #555 !important;
    }

    .dark-mode .text-muted {
      color: #cccccc !important;
    }

    .app-content h3 {
      margin-top: 0px !important;
    }

    </style>',
    $page
);

/* JAVASCRIPT */
$page = str_replace(
    '</body>',
    '

<script>

/* APPLY DARK MODE */
if (localStorage.getItem("darkMode") === "enabled") {
  document.body.classList.add("dark-mode");
}

/* SWITCH */
const darkSwitch = document.getElementById("darkModeSwitch");

if (darkSwitch) {

  if (localStorage.getItem("darkMode") === "enabled") {
    darkSwitch.checked = true;
  }

  darkSwitch.addEventListener("change", function () {

    if (this.checked) {

      document.body.classList.add("dark-mode");

      localStorage.setItem(
        "darkMode",
        "enabled"
      );

    } else {

      document.body.classList.remove("dark-mode");

      localStorage.setItem(
        "darkMode",
        "disabled"
      );

    }

  });

}

/* CHATBOT */
function chatReply() {

  const input =
  document.getElementById("chatInput");

  const chatBox =
  document.getElementById("chatBox");

  const question =
  input.value.trim();

  if (question === "") return;

  const q =
  question.toLowerCase();

  let answer =
  "Sorry, I did not understand that.";

  if (
    q.includes("hi") ||
    q.includes("hello")
  ) {

    answer =
    "Hello! How can I help you today?";

  }

  else if (
    q.includes("riot")
  ) {

    answer =
    "Go to Dashboard and enter your Riot ID like ARKO#2005.";

  }

  else if (
    q.includes("analytics")
  ) {

    answer =
    "Analytics shows player performance and match trends.";

  }

  else if (
    q.includes("logout")
  ) {

    answer =
    "Use Logout from the sidebar.";

  }

  else if (
    q.includes("stats")
  ) {

    answer =
    "Stats are available from Analytics and Dashboard.";

  }

  else if (
    q.includes("team")
  ) {

    answer =
    "Teams section manages esports teams.";

  }

  chatBox.innerHTML +=
  "<div class=\'mt-2 text-end\'><b>You:</b> " +
  question +
  "</div>";

  chatBox.innerHTML +=
  "<div class=\'mt-2\'><b>Bot:</b> " +
  answer +
  "</div>";

  input.value = "";

  chatBox.scrollTop =
  chatBox.scrollHeight;
}

/* ENTER KEY */
document
.getElementById("chatInput")
.addEventListener(
  "keydown",
  function(event) {

    if (event.key === "Enter") {
      event.preventDefault();
      chatReply();
    }

  }
);

</script>

</body>',
    $page
);

echo $page;
?>