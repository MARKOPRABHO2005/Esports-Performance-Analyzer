<?php
session_start();
include "db.php";

if (!isset($_SESSION['user'])) {
    header("Location: /login.php");
    exit();
}

$email = $_SESSION['user'];

$stmt = $conn->prepare("SELECT riot_id FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

$riot_id = "";

if ($row = $result->fetch_assoc()) {
    $riot_id = $row['riot_id'] ?? "";
}

if (empty($riot_id)) {
    header("Location: /profile.php");
    exit();
}

/* Tracker Performance URL */
$performanceUrl = "https://tracker.gg/valorant/profile/riot/" 
    . rawurlencode($riot_id) 
    . "/performance";

/* Redirect directly */
header("Location: " . $performanceUrl);
exit();
?>