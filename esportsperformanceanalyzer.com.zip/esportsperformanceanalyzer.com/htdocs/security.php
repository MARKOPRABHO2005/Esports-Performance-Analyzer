<?php
session_start();

$name = $_SESSION['name'] ?? "Account";
$email = $_SESSION['user'] ?? "Not logged in";
$isLoggedIn = isset($_SESSION['user']);
?>

<!doctype html>
<html>
<head>
  <title>Privacy & Security</title>
  <link rel="icon" type="image/png" href="/dist/assets/img/Logo.png">
  <link rel="stylesheet" href="/dist/css/adminlte.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css">
</head>

<body class="p-4 bg-light">

  <div class="container">
    <h2><i class="bi bi-shield-lock"></i> Privacy & Security</h2>
    <p>Manage your account security and login information.</p>

    <div class="card mb-3">
      <div class="card-body">
        <h5>Login Status</h5>
        <p><b>Status:</b> <?php echo $isLoggedIn ? "Logged in" : "Not logged in"; ?></p>
        <p><b>Email:</b> <?php echo htmlspecialchars($email); ?></p>
        <p><b>Name:</b> <?php echo htmlspecialchars($name); ?></p>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
        <h5>Account Actions</h5>

        <?php if ($isLoggedIn): ?>
          <a href="/logout.php" class="btn btn-danger">Logout from this device</a>
        <?php else: ?>
          <a href="/login.php" class="btn btn-primary">Login</a>
        <?php endif; ?>

        <a href="/settings.php" class="btn btn-secondary">Back to Settings</a>
      </div>
    </div>
  </div>

</body>
</html>