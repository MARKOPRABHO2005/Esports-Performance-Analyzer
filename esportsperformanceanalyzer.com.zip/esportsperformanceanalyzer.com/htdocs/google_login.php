<?php
$client_id = "1031095676164-2eo37u5ns7e254n275ocjiqng2cm8dt6.apps.googleusercontent.com";

$redirect_uri = "https://esportsperformanceanalyzer.com/google_callback.php";

$scope = "email profile";

$url = "https://accounts.google.com/o/oauth2/v2/auth?" . http_build_query([
    "client_id" => $client_id,
    "redirect_uri" => $redirect_uri,
    "response_type" => "code",
    "scope" => $scope,
    "access_type" => "online",
    "prompt" => "select_account consent"
]);

header("Location: $url");
exit();