<?php
session_start();
include "db.php";
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user['email'];
            $emailName = explode("@", $user['email'])[0];
$emailName = preg_replace('/[^a-zA-Z]/', ' ', $emailName);
$emailName = strtoupper(trim($emailName));

$_SESSION['name'] = !empty($user['name']) ? $user['name'] : $emailName;

            header("Location: /dashboard.php");
            exit();
        } else {
            $error = "Incorrect password. Please try again.";
        }
    } else {
        $error = "Email not found. Please register first.";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login | Esports Performance Analyzer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="icon" href="dist/assets/img/Logo.png">
  <link rel="stylesheet" href="dist/css/adminlte.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
.dark-mode {
  background-color: #121212 !important;
  color: #ffffff !important;
}

.dark-mode .login-box,
.dark-mode .register-box,
.dark-mode .card,
.dark-mode .login-card-body,
.dark-mode .register-card-body {
  background-color: #1f1f1f !important;
  color: #ffffff !important;
}

.dark-mode .form-control {
  background-color: #2a2a2a !important;
  color: #ffffff !important;
  border-color: #555 !important;
}

.dark-mode .form-control::placeholder {
  color: #cccccc !important;
}

.dark-mode a {
  color: #66b2ff !important;
}
</style>
</head>

<body class="login-page bg-body-secondary">

<div class="login-box">

  <div class="login-logo text-center mb-3">
    <a href="index.php" class="h3 text-dark">Esports Performance Analyzer</a>
  </div>

  <div class="card">
    <div class="card-body login-card-body">

      <p class="login-box-msg">Sign in to your account</p>
        <?php if (!empty($error)) { ?>
  <div class="alert alert-danger text-center">
    <?php echo $error; ?>
  </div>
<?php } ?>

      <form method="POST" autocomplete="off">

        <div class="input-group mb-3">
          <input
  			type="email"
  			name="email"
  			class="form-control"
  			placeholder="Enter your email"
  			autocomplete="new-email"
  			required
         >
          <div class="input-group-text">
            <span class="bi bi-envelope"></span>
          </div>
        </div>

        <div class="input-group mb-3">
          <input
  			type="password"
  			id="password"
  			name="password"
  			class="form-control"
  			placeholder="Enter Password"
  			autocomplete="new-password"
  			required
          >
          <div class="input-group-text" style="cursor:pointer;" onclick="togglePassword()">
            <span id="eyeIcon" class="bi bi-eye-slash"></span>
          </div>
        </div>

        <div class="d-grid mb-3">
          <button type="submit" class="btn btn-primary">Login</button>
        </div>
          
          <div class="text-end mb-3">
  <a href="forgot-password.php">Forgot Password?</a>
</div>

      </form>

      <div class="social-auth-links text-center mt-3">
        <p>- OR -</p>

        <a href="google_login.php"
           class="btn w-100 mb-2 d-flex align-items-center justify-content-center"
           style="border: 1px solid #ddd; background: white; color: #444;">
          <img src="dist/assets/img/Google.png" style="width:45px; margin-right:10px;">
          Continue with Google
        </a>
      </div>

      <a href="register.php">Don't have an account? Register</a>

    </div>
  </div>

</div>

<script src="dist/js/adminlte.js"></script>

<script>
function togglePassword() {
  const password = document.getElementById("password");
  const icon = document.getElementById("eyeIcon");

  if (password.type === "password") {
    password.type = "text";
    icon.classList.remove("bi-eye-slash");
    icon.classList.add("bi-eye");
  } else {
    password.type = "password";
    icon.classList.remove("bi-eye");
    icon.classList.add("bi-eye-slash");
  }
}
</script>
    <script>
if (localStorage.getItem("darkMode") === "enabled") {
  document.body.classList.add("dark-mode");
}
</script>

</body>
</html>