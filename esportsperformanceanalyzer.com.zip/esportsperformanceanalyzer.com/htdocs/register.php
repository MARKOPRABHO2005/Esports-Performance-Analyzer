<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $riot_id = $_POST['riot_id'] ?? "";

    $check = $conn->query("SELECT * FROM users WHERE email='$email'");

    if ($check->num_rows > 0) {
    echo "<script>alert('Email already registered. Please login.'); window.location='login.php';</script>";
} else {
    $conn->query("INSERT INTO users (email, password, riot_id) VALUES ('$email', '$password', '$riot_id')");
    echo "<script>alert('Registered successfully'); window.location='login.php';</script>";
}
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Register | Esports Performance Analyzer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Favicon -->
  <link rel="icon" href="dist/assets/img/Logo.png">

  <!-- AdminLTE CSS -->
  <link rel="stylesheet" href="dist/css/adminlte.css">

  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
.dark-mode {
  background-color: #121212 !important;
  color: #ffffff !important;
}

.dark-mode .login-box,
.dark-mode .register-box,
.dark-mode .card,
.dark-mode .login-card-body,
.dark-mode .register-card-body {
  background-color: #1f1f1f !important;
  color: #ffffff !important;
}

.dark-mode .form-control {
  background-color: #2a2a2a !important;
  color: #ffffff !important;
  border-color: #555 !important;
}

.dark-mode .form-control::placeholder {
  color: #cccccc !important;
}

.dark-mode a {
  color: #66b2ff !important;
}
</style>
</head>

<body class="register-page bg-body-secondary">

<div class="register-box">

  <div class="register-logo text-center mb-3">
    <a href="index.php" class="h3 text-dark">Esports Performance Analyzer</a>
  </div>

  <div class="card">
    <div class="card-body login-card-body">

      <p class="login-box-msg">Create/Register an account</p>

      <form method="POST" autocomplete="off">

        <!-- Email -->
        <div class="input-group mb-3">
          <input
  			type="email"
  			name="email"
  			class="form-control"
  			placeholder="Enter your email"
  			autocomplete="new-email"
  			required
          >
          <div class="input-group-text"><span class="bi bi-envelope"></span></div>
        </div>

        <!-- Password -->
<div class="input-group mb-3">

  <input
    type="password"
    id="password"
    name="password"
    class="form-control"
    placeholder="Enter Password"
    autocomplete="new-password"
    required
  >

  <div
    class="input-group-text"
    style="cursor:pointer;"
    onclick="togglePassword()"
  >
    <span id="eyeIcon" class="bi bi-eye-slash"></span>
  </div>

</div>

        <!-- Riot ID -->
        <div class="input-group mb-3">
          <input type="text" name="riot_id" class="form-control" placeholder="Enter Riot ID (e.g., Riju#1234)">
          <div class="input-group-text"><span class="bi bi-controller"></span></div>
        </div>

          <div class="col-4">
            <button type="submit" class="btn btn-primary w-100">Register</button>
          </div>
        </div>

      </form>

      <div class="social-auth-links text-center mt-3">
        <p>- OR -</p>

        <!-- Google Login -->
        <a href="google_login.php"
           class="btn w-100 mb-2 d-flex align-items-center justify-content-center"
           style="border: 1px solid #ddd; background: white; color: #444;">
          <img src="dist/assets/img/Google.png" style="width:45px; margin-right:10px;">
          Continue with Google
        </a>

      </div>

      <a href="login.php">Already have an account? Sign In</a>

    </div>
  </div>

</div>

<script src="dist/js/adminlte.js"></script>
<script>
function togglePassword() {

  const password =
  document.getElementById("password");

  const icon =
  document.getElementById("eyeIcon");

  if (password.type === "password") {

    password.type = "text";

    icon.classList.remove("bi-eye-slash");
    icon.classList.add("bi-eye");

  } else {

    password.type = "password";

    icon.classList.remove("bi-eye");
    icon.classList.add("bi-eye-slash");
  }
}
</script>
    <script>
if (localStorage.getItem("darkMode") === "enabled") {
  document.body.classList.add("dark-mode");
}
</script>
</body>
</html>