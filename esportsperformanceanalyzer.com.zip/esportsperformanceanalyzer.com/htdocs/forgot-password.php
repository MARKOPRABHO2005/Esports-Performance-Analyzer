<?php
session_start();
include "db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    if ($new_password !== $confirm_password) {

        $message = "Passwords do not match.";

    } else {

        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("UPDATE users SET password=? WHERE email=?");
        $stmt->bind_param("ss", $hashed_password, $email);

        if ($stmt->execute() && $stmt->affected_rows > 0) {

            header("Location: login.php");
            exit();

        } else {

            $message = "Email not found.";
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Forgot Password | Esports Performance Analyzer</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="./dist/css/adminlte.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

  <style>
    body {
      background-color: #f4f6f9;
    }

    .forgot-box {
      width: 420px;
      margin: 80px auto;
    }

    .card {
      padding: 20px;
    }
  </style>
</head>

<body>

<div class="forgot-box">

  <h1 class="text-center mb-4">
    Esports Performance Analyzer
  </h1>

  <div class="card shadow">

    <h4 class="text-center mb-4">
      Reset Your Password
    </h4>

    <?php if (!empty($message)): ?>
      <div class="alert alert-danger">
        <?php echo htmlspecialchars($message); ?>
      </div>
    <?php endif; ?>

    <form method="POST">

      <div class="mb-3">
        <input 
          type="email"
          name="email"
          class="form-control"
          placeholder="Enter your email"
          required
        >
      </div>

      <div class="mb-3">
        <input 
          type="password"
          name="new_password"
          class="form-control"
          placeholder="New Password"
          required
        >
      </div>

      <div class="mb-3">
        <input 
          type="password"
          name="confirm_password"
          class="form-control"
          placeholder="Confirm Password"
          required
        >
      </div>

      <button type="submit" class="btn btn-primary w-100">
        Done
      </button>

    </form>

    <div class="text-center mt-3">
      <a href="login.php">
        Back to Login
      </a>
    </div>

  </div>
</div>

<script src="./dist/js/adminlte.js"></script>

</body>
</html>