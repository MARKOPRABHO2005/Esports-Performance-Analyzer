<?php
session_start();
include "db.php";

$isLoggedIn = isset($_SESSION['user']);
$email = $_SESSION['user'] ?? "";
$name = $_SESSION['name'] ?? "Account";
$riot_id = "";

/* Remove Riot ID */
if ($isLoggedIn && isset($_POST['remove_riot'])) {

    $stmt = $conn->prepare(
        "UPDATE users SET riot_id='' WHERE email=?"
    );

    $stmt->bind_param("s", $email);
    $stmt->execute();

    header("Location: /");
    exit();
}

/* Save/Update Riot ID */
if ($isLoggedIn && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['riot_id'])) {
    $new_riot_id = trim($_POST['riot_id']);

    $stmt = $conn->prepare("UPDATE users SET riot_id=? WHERE email=?");
    $stmt->bind_param("ss", $new_riot_id, $email);
    $stmt->execute();

    header("Location: /");
    exit();
}

/* Get Riot ID automatically from database */
if ($isLoggedIn) {
    $stmt = $conn->prepare("SELECT riot_id FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $riot_id = $row['riot_id'] ?? "";
    }
}

$page = file_get_contents("dist/index.html");

/* Fix CSS/JS/image paths */
$page = str_replace("<head>", "<head>\n<base href='dist/'>", $page);

$page = str_replace('href="./index.html"', 'href="/"', $page);
$page = str_replace('href="index.html"', 'href="/"', $page);
$page = str_replace('href="../index.html"', 'href="/"', $page);
$page = str_replace('href="/dist/index.html"', 'href="/"', $page);
$page = str_replace('href="dist/index.html"', 'href="/"', $page);

/* Navbar account name */
$page = str_replace(
    '<i class="bi bi-person-circle"></i> Account',
    '<i class="bi bi-person-circle"></i> ' . htmlspecialchars($name),
    $page
);

/* Tracker / Riot ID section */
$trackerSection = "";

if ($isLoggedIn) {
    if (!empty($riot_id)) {
        $trackerUrl = "https://tracker.gg/valorant/profile/riot/" . rawurlencode($riot_id) . "/overview";

        $trackerSection = '
<div class="card mb-4">
  <div class="card-body">

    <h5 class="card-title">Linked Riot ID</h5>

    <p class="card-text">
      <b>' . htmlspecialchars($riot_id) . '</b>
    </p>

    <a href="' . $trackerUrl . '" target="_blank" class="btn btn-danger me-2">
      View Valorant Stats
    </a>

    <form method="POST" action="/" style="display:inline;">
      <input type="hidden" name="remove_riot" value="1">
      <button type="submit" class="btn btn-secondary">
        Remove Riot ID
      </button>
    </form>

  </div>
</div>';
    } else {
        $trackerSection = '
        <div class="card mb-4">
          <div class="card-body">
            <h5 class="card-title">Link Riot ID</h5>
            <form method="POST" action="/">
              <div class="input-group">
                <input type="text" name="riot_id" class="form-control" placeholder="Enter Riot ID e.g. Riju#1234" required>
                <button type="submit" class="btn btn-primary">Save Riot ID</button>
              </div>
            </form>
          </div>
        </div>';
    }
}
$dashboardCards = '
<div class="row mb-4">

  <div class="col-md-4">
    <a href="/matches.php" class="text-decoration-none">
      <div class="small-box text-bg-success">
        <div class="inner">
          <h3>Matches</h3>
          <p>View Tracker Network matches</p>
        </div>
        <div class="small-box-icon">
          <i class="bi bi-controller"></i>
        </div>
      </div>
    </a>
  </div>

  <div class="col-md-4">
    <a href="/player-stats.php" class="text-decoration-none">
      <div class="small-box text-bg-warning">
        <div class="inner">
          <h3>Player Stats</h3>
          <p>View performance stats</p>
        </div>
        <div class="small-box-icon">
          <i class="bi bi-bar-chart"></i>
        </div>
      </div>
    </a>
  </div>

  <div class="col-md-4">
    <a href="/analytics.php" class="text-decoration-none">
      <div class="small-box text-bg-danger">
        <div class="inner">
          <h3>Analytics</h3>
          <p>Performance insights</p>
        </div>
        <div class="small-box-icon">
          <i class="bi bi-graph-up-arrow"></i>
        </div>
      </div>
    </a>
  </div>

</div>
';

/* Insert Tracker section and dashboard cards after dashboard intro */
$page = str_replace(
    '<p class="fs-5 mb-4">Track players, games, matches, and performance statistics in one place.
</p>',
    '<p class="fs-5 mb-4">Track players, games, matches, and performance statistics in one place.
</p>' . $trackerSection . $dashboardCards,
    $page
);

if ($isLoggedIn) {

    /* Top dropdown */
    $page = str_replace(
        '<a class="dropdown-item" href="../register.php">Register / Sign Up</a>',
        '<span class="dropdown-item-text">Logged in as:<br><b>' . htmlspecialchars($email) . '</b></span>',
        $page
    );

    $page = str_replace(
        '<a class="dropdown-item" href="../login.php">Already a user? Login</a>',
        '<a class="dropdown-item" href="/logout.php">Logout</a>',
        $page
    );

    /* Sidebar Register -> Logout */
    $page = str_replace(
        '<a href="../register.php" class="nav-link">',
        '<a href="/logout.php" class="nav-link">',
        $page
    );

    $page = str_replace(
        '<p>Register</p>',
        '<p>Logout</p>',
        $page
    );

    $page = str_replace(
        'bi bi-person-plus',
        'bi bi-box-arrow-right',
        $page
    );

    /* Remove Login completely */
    $loginBlock = '
<li class="nav-item">
  <a href="../login.php" class="nav-link">
    <i class="nav-icon bi bi-box-arrow-in-right"></i>
    <p>Login</p>
  </a>
</li>';

    $page = str_replace($loginBlock, '', $page);

} else {

    $page = str_replace('../register.php', '/register.php', $page);
    $page = str_replace('../login.php', '/login.php', $page);
}
echo $page;
?>