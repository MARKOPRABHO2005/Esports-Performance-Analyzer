<?php
$conn = new mysqli(
    "sql102.infinityfree.com",
    "if0_41777727",
    "6h0Jy3Bz8kmXtzt",
    "if0_41777727_esports"
);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>